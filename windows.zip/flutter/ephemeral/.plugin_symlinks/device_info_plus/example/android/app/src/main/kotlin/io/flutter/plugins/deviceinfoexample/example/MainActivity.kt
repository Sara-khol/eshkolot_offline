package io.flutter.plugins.deviceinfoexample.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
