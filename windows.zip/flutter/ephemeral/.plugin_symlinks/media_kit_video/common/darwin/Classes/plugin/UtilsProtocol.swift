public protocol UtilsProtocol: NSObject {
  func enterNativeFullscreen()
  func exitNativeFullscreen()
}
