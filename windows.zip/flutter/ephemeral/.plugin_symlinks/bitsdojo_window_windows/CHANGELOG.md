## 0.1.6
    - Various fixes to work with latest Flutter version
## 0.1.5
    - Runs on Windows 7
## 0.1.4
    - Updated win32 to 3.0.0
## 0.1.3
    - Updated ffi to 2.0.0
## 0.1.2
    - Flutter 3.0 support
## 0.1.0
    - Added null safety support
## 0.0.3

* Deprecated some methods
## 0.0.2

* Upgraded to ffi 1.0.0 and win32 2.0.0
## 0.0.1

* Initial Windows release as federated plugin