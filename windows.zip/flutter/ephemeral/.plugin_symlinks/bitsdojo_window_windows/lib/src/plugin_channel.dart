import 'package:flutter/services.dart';

const String _channelName = "bitsdojo/window";

MethodChannel bitsDojoWindowChannel = const MethodChannel(_channelName);
