import 'package:bitsdojo_window_platform_interface/bitsdojo_window_platform_interface.dart';

abstract class WinDesktopWindow extends DesktopWindow {
  void setWindowCutOnMaximize(int value);
}
