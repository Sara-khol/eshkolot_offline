export 'src/bitsdojo_window_windows_stub.dart'
    if (dart.library.ffi) 'src/bitsdojo_window_windows_real.dart';
