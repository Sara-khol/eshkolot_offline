// Relative import to be able to reuse the C sources.
// See the comment in ../{projectName}}.podspec for more information.
#include "../../common/darwin/Sources/signal_recovery.c"
