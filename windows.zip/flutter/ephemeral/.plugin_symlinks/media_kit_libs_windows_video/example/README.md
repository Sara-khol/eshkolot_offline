## Installation

Add in your `pubspec.yaml`:

```yaml
dependencies:
  media_kit_libs_windows_audio: ^1.0.9
```

This will automatically bundle required shared libraries for video (& audio) playback on Windows.
